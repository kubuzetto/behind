# behind!

![behind!](/icon256.png?raw=true )

![Mozilla Add-on](https://img.shields.io/amo/v/behind?style=flat-square) ![Mozilla Add-on](https://img.shields.io/amo/users/behind?style=flat-square) ![Mozilla Add-on](https://img.shields.io/amo/stars/behind?style=flat-square)

![Chrome Web Store](https://img.shields.io/chrome-web-store/v/blfpdedbdighagggfhgihcocfheicfjk?style=flat-square) ![Chrome Web Store](https://img.shields.io/chrome-web-store/users/blfpdedbdighagggfhgihcocfheicfjk?style=flat-square) ![Chrome Web Store](https://img.shields.io/chrome-web-store/stars/blfpdedbdighagggfhgihcocfheicfjk?style=flat-square)

![PRs welcome!](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=for-the-badge)

When "view background image" is greyed out, this add-on is there to help you.

behind! can reveal:

- Background images,
- Images under layers of nonsense (e.g. clickable surfaces designed to hide the image from you),
- Embedded images / base64-encoded image chunks,
- Alternative resolutions ,
- Vector images (even when they are inlined),
- Images in shadow DOM

[Link to the Firefox addon page](https://addons.mozilla.org/en-US/firefox/addon/behind/)

[Link to the Chrome extension page](https://chrome.google.com/webstore/detail/behind/blfpdedbdighagggfhgihcocfheicfjk?hl=en&authuser=0)
